This directory contains the files needed to make Linux understand that
Tellstick and FHZ1000/FHZ1300 behave like ftdi serial ports.

to install them, make the install.sh executable and run it as root:

>chmod +x install.sh
>sudo ./install.sh

Then plug in the device and it should appear as a serial port.
